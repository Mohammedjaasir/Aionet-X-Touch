"use client";

import ErrorReporter from "@/components/ErrorReporter";

export default ErrorReporter;
