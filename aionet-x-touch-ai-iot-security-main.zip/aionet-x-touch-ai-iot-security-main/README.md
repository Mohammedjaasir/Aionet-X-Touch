# AIONet-X Touch – Emotion-Aware, GenAI-Powered Self-Healing IoT Security Platform

![AIONet-X Touch](https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1200&h=400&fit=crop)

## 🚀 Overview

**AIONet-X Touch** is a cutting-edge, futuristic web application that simulates an AI-based IoT security platform. The system features real-time threat detection, emotion sensing, GenAI explanations, and automatic self-healing capabilities—all wrapped in a stunning neon blue/dark themed interface with advanced animations.

## ✨ Features

### 🎯 Core Capabilities

- **🛡️ Real-Time Threat Detection**: AI-powered anomaly detection monitoring IoT devices
- **😊 Emotion Recognition**: Live emotion detection with confidence scoring
- **🤖 GenAI Assistant**: Interactive chatbot explaining system actions and security events
- **⚡ Self-Healing System**: Automatic recovery and threat neutralization
- **📊 Live Dashboard**: Real-time device monitoring with health metrics
- **📝 System Logs**: Complete activity timeline with recovery status tracking

### 🎨 Design Features

- **Futuristic UI**: Neon blue/cyan theme with glowing effects
- **Smooth Animations**: Powered by Framer Motion
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Glass Morphism**: Backdrop blur effects with transparency
- **Live Status Indicators**: Pulsing animations and scanning effects
- **Professional Imagery**: High-quality cybersecurity visuals

## 🏗️ Architecture

### Frontend Stack
- **Framework**: Next.js 15 (React 19)
- **Styling**: TailwindCSS v4
- **UI Components**: Shadcn/UI
- **Animations**: Framer Motion
- **Language**: TypeScript

### Key Components

1. **LandingPage**: Animated intro with feature cards and CTA
2. **Dashboard**: IoT device monitoring with threat alerts
3. **EmotionDetection**: Webcam simulation with emotion analysis and AI chat
4. **SystemLogs**: Activity timeline with recovery metrics
5. **Navigation**: Responsive navigation with mobile support

## 🎯 Pages & Sections

### 1. Landing Page
- Animated hero section with glowing effects
- Feature showcase (AI Detection, Emotion Sensing, Self-Healing, Live Monitoring)
- "Start Simulation" CTA button with hover animations
- Decorative corner accents

### 2. Security Dashboard
- System health overview with progress indicators
- 3 simulated IoT devices (Smart Door Lock, Security Camera, Temperature Sensor)
- Real-time threat alerts with severity levels
- Device health metrics and status badges
- Statistics cards (AI Scans, Auto-Recoveries, Threats Blocked)

### 3. Emotion Detection & AI Assistant
- **Left Panel**: Live emotion feed with facial detection overlay
  - Scanning line animation
  - Real-time emotion classification (Happy, Neutral, Concerned, Panic)
  - Confidence percentage display
  - Emotion analysis breakdown with progress bars

- **Right Panel**: GenAI Chat Interface
  - Interactive messaging with AI assistant
  - Contextual responses about security events
  - User/AI message differentiation
  - Timestamp tracking

### 4. System Logs & Recovery
- **Stats Overview**: Auto-recoveries, success rate, response time, active threats
- **Activity Timeline**: Chronological log entries with status indicators
  - Recovery events (self-healing)
  - Threat neutralization logs
  - AI security scans
  - System updates
- **Recovery Status Panel**: Real-time metrics (Network, Device Health, AI Response)
- **Security Center Visual**: Monitoring center with scanning grid overlay

## 🎨 Visual Design System

### Color Palette
```css
--neon-blue: #00d4ff      /* Primary accent */
--neon-cyan: #00ffff      /* Secondary accent */
--cyber-purple: #9d4edd   /* Tertiary accent */
--dark-bg: #0a0a0f        /* Background */
--darker-bg: #050508      /* Deeper background */
--threat-red: #ff0055     /* Danger/threats */
--safe-green: #00ff88     /* Success/safe */
```

### Effects
- **Glow Effects**: Box shadows with neon colors
- **Text Glow**: Text shadows for enhanced visibility
- **Pulse Animation**: Breathing effects for live indicators
- **Scanning Lines**: Animated gradients for tech feel
- **Grid Pattern**: Subtle background grid overlay
- **Gradient Shifts**: Animated background gradients

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or Bun
- npm/yarn/pnpm/bun

### Installation

```bash
# Install dependencies
npm install
# or
bun install

# Run development server
npm run dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) to view the application.

### Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout with metadata
│   ├── page.tsx            # Main app with state management
│   └── globals.css         # Global styles with custom CSS variables
├── components/
│   ├── LandingPage.tsx     # Animated intro/landing
│   ├── Navigation.tsx      # Top navigation bar
│   ├── Dashboard.tsx       # IoT device monitoring
│   ├── EmotionDetection.tsx # Emotion AI & chat
│   └── SystemLogs.tsx      # Logs & recovery view
└── components/ui/          # Shadcn UI components
```

## 🎭 Simulated Features

### IoT Devices
- **Smart Door Lock**: Security device with authentication tracking
- **Security Camera**: Surveillance with feed monitoring
- **Temperature Sensor**: Environment monitoring with anomaly detection

### Threat Scenarios
- Unauthorized access attempts
- Temperature anomalies
- Network intrusions
- Failed authentication
- Suspicious activity patterns

### Auto-Recovery Actions
- Device recalibration
- Network optimization
- Security protocol enhancement
- System updates
- Threat neutralization

## 🔮 Future Enhancements

While this is a frontend simulation, future backend integration could include:

### Backend (Conceptual)
- **Python + Flask**: REST API server
- **AI/ML Models**: 
  - Scikit-learn for anomaly detection
  - DeepFace for emotion recognition
  - OpenAI GPT-4 for GenAI chat
- **Database**: MongoDB for logs and device data
- **Real-Time**: WebSocket connections for live updates
- **Voice Features**: Speech-to-text and TTS

### Endpoints (Conceptual)
```
POST /api/detect    - AI threat detection
POST /api/emotion   - Emotion analysis
POST /api/chat      - GenAI conversation
POST /api/heal      - Trigger self-healing
GET  /api/devices   - Device status
GET  /api/logs      - System logs
```

## 📸 Screenshots

### Landing Page
Futuristic hero section with animated elements and feature cards

### Dashboard
Real-time IoT device monitoring with threat detection

### Emotion AI
Live emotion detection with GenAI chat assistant

### System Logs
Activity timeline with self-healing recovery status

## 🛠️ Technologies Used

- **Next.js 15**: React framework with App Router
- **React 19**: Latest React with modern hooks
- **TypeScript**: Type-safe development
- **Tailwind CSS v4**: Utility-first styling
- **Shadcn/UI**: Beautiful component library
- **Framer Motion**: Advanced animations
- **Lucide React**: Icon system
- **Next/Image**: Optimized images

## 📝 Key Features Implementation

### Real-Time Simulation
- `useEffect` hooks simulate live data updates
- Interval-based state changes for dynamic content
- Random data generation for realistic behavior

### Animation Strategy
- Staggered entry animations for list items
- Hover effects with scale and shadow transitions
- Infinite pulse animations for live indicators
- Scanning line effects for tech aesthetic

### Responsive Design
- Mobile-first approach
- Breakpoints: `sm`, `md`, `lg`, `xl`
- Collapsible mobile navigation
- Adaptive grid layouts

## 🎯 Use Cases

- **Security Demonstrations**: Showcase IoT security concepts
- **AI/ML Prototyping**: Visualize AI-powered security systems
- **Portfolio Projects**: Demonstrate full-stack capabilities
- **Educational Tool**: Teach cybersecurity concepts
- **Proof of Concept**: Present futuristic security ideas

## 🤝 Contributing

This is a demonstration project. Feel free to fork and enhance with:
- Additional device types
- More emotion categories
- Enhanced AI responses
- Backend integration
- Real WebRTC camera feed
- Voice command features

## 📄 License

MIT License - feel free to use for your projects

## 👨‍💻 Author

Built with Next.js, React, and lots of neon blue ✨

---

**Note**: This is a frontend simulation. All AI detection, emotion recognition, and self-healing features are simulated for demonstration purposes. For production use, integrate with real AI/ML backends and IoT device APIs.